import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    private httpClient: HttpClient
  ) { }

  getPatients() {
    return this.httpClient.get(environment.queryURI + '/Patient',
      { headers: this.getHeaders() });
  }

  getPatientsByBirthdate(gtDate: string = '1960-01-01', ltDate: string = '1965-12-31') {
    return this.httpClient.get(environment.queryURI + `/Patient?birthdate=gt${gtDate}&birthdate=lt${ltDate}`,
      { headers: this.getHeaders() });
  }

  search({ birthDate, name }: SearchParams) {
    // let url = environment.queryURI + `/Patient?`;
    let params = new HttpParams();
    if (name) {
      params = params.append('name', name);
    }
    if (birthDate) {
      params = params.append('birthdate', birthDate);
    }

    return this.httpClient.get(environment.queryURI + '/Patient',
    { params: params, headers: this.getHeaders() });
  }

  private getHeaders(): HttpHeaders {
    const headers = new HttpHeaders({
      'Content-Type': 'application/fhir+json'
    });
    return headers;
  }
}


export interface SearchParams {
  birthDate?: string;
  name?: string;

}
