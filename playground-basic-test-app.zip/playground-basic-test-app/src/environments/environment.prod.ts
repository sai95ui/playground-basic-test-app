export const environment = {
  production: true,
  queryURI: 'http://hapi.fhir.org/baseR4'
};
